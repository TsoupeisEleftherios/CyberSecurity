import subprocess
import re

def scan_ports(ip):
    try:
        result = subprocess.run(
            ["nmap", "-Pn", "--top-ports", "500", "-T4", "--min-rate", "1000", ip],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True
        )
        output = result.stdout
        ports = re.findall(r"(\d{1,5})/tcp\s+open", output)
        return list(map(int, ports))
    except Exception as e:
        print(f"[!] Nmap scan failed for {ip}: {e}")
        return []
