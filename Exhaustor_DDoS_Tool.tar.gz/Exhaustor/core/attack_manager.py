import threading
from collections import defaultdict
from threading import Lock

class AttackManager:
    def __init__(self):
        # Tracks which attacks are active per IP
        self.active_attacks = defaultdict(set)  # ip -> set of attack names
        
        # Traffic stats per IP: {'sent': int, 'fail': int}
        self.traffic_stats = defaultdict(lambda: {'sent': 0, 'fail': 0})
        
        self.stats_lock = Lock()  # Protects access to active_attacks and traffic_stats
        
        # Stop events to control attack threads per IP
        self.stop_events = {}  # ip -> threading.Event()

    def ensure_stop_event(self, ip):
        """
        Get or create a threading.Event for stopping attacks on given IP.
        """
        if ip not in self.stop_events:
            self.stop_events[ip] = threading.Event()
        else:
            if self.stop_events[ip].is_set():
                self.stop_events[ip].clear()
        return self.stop_events[ip]

    def add_attack(self, ip, attack_name):
        """
        Mark attack_name as active on ip.
        """
        with self.stats_lock:
            self.active_attacks[ip].add(attack_name)

    def remove_attack(self, ip, attack_name):
        """
        Mark attack_name as stopped on ip.
        """
        with self.stats_lock:
            self.active_attacks[ip].discard(attack_name)

    def stop_attacks(self, ip=None):
        """
        Signal stop to attack threads.
        If ip is None, stop all attacks.
        """
        if ip:
            if ip in self.stop_events:
                self.stop_events[ip].set()
        else:
            for e in self.stop_events.values():
                e.set()

    def get_status(self):
        """
        Get current status of all IPs with active attacks and traffic stats.
        """
        with self.stats_lock:
            return {
                ip: {
                    "active_attacks": list(self.active_attacks.get(ip, [])),
                    "sent": self.traffic_stats[ip]['sent'],
                    "fail": self.traffic_stats[ip]['fail'],
                }
                for ip in self.active_attacks
            }
