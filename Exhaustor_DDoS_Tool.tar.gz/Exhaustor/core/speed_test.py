import speedtest

def simulate_speed(packet_size_bytes=1500):
    st = speedtest.Speedtest()
    st.get_best_server()
    
    download_bps = st.download()  # bits per second
    upload_bps = st.upload()      # bits per second

    packet_size_bits = packet_size_bytes * 8
    pps = upload_bps / packet_size_bits

    upload_mbps = upload_bps / 1_000_000
    download_mbps = download_bps / 1_000_000

    print(f"Upload speed: {upload_mbps:.2f} Mbps")
    print(f"Download speed: {download_mbps:.2f} Mbps")
    print(f"Estimated packets per second (packet size {packet_size_bytes} bytes): {pps:.0f}")

    return {
        "upload_mbps": upload_mbps,
        "download_mbps": download_mbps,
        "pps": int(pps)
    }

if __name__ == "__main__":
    results = simulate_speed()
    print(results)
