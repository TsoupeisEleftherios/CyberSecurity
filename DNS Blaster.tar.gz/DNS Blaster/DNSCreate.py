#!/usr/bin/env python3
import argparse
import random
import string

def random_subdomain(length=8):
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))

def main():
    parser = argparse.ArgumentParser(description="Generate random subdomains and save to file.")
    parser.add_argument('-n', '--number', type=int, required=True, help="Number of domains to generate")
    parser.add_argument('-d', '--domain', type=str, default="example.com", help="Base domain")
    parser.add_argument('-o', '--output', type=str, default="domains.txt", help="Output filename")
    args = parser.parse_args()

    with open(args.output, 'w') as f:
        for _ in range(args.number):
            subdomain = random_subdomain() + '.' + args.domain
            f.write(subdomain + '\n')

    print(f"[+] Generated {args.number} domains and saved to {args.output}")

if __name__ == "__main__":
    main()
